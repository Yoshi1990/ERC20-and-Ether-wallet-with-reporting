# ETH-and-ERC20-token-wallet

A javascript based wallet for managing and reporting on a specific ERC20 token, designed for use with new tokens (ICO's).
